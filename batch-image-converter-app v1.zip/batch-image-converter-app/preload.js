const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  selectInputFolder: () => ipcRenderer.invoke('select-input-folder'),
  selectOutputFolder: () => ipcRenderer.invoke('select-output-folder'),
  readFile: (filePath) => ipcRenderer.invoke('read-file', filePath),
  saveFile: (outputFolder, fileName, data) => ipcRenderer.invoke('save-file', outputFolder, fileName, data),
  revealFile: (filePath) => ipcRenderer.invoke('reveal-file', filePath)
});
